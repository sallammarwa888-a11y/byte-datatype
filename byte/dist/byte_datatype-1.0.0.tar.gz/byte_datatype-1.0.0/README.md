# Byte

A simple unsigned 8-bit integer datatype for Python.

```python
from byte import Byte

x = Byte(250)
print(x + 10)  # Byte(4)
```